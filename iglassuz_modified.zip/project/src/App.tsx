import React from 'react';
import Home from './pages/Home';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-blue-50">
      <Home />
    </div>
  );
}

export default App;